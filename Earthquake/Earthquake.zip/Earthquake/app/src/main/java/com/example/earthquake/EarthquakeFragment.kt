package com.example.earthquake

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.earthquake.adapter.EarthquakeAdapter
import com.example.earthquake.databinding.FragmentEarthquakeBinding
import com.example.earthquake.viewmodels.EarthquakeViewModel

class EarthquakeFragment : Fragment() {
    private lateinit var binding: FragmentEarthquakeBinding
    private val earthquakeViewModel: EarthquakeViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentEarthquakeBinding.inflate(inflater, container, false)
        val adapter= EarthquakeAdapter()
        binding.eqlistRV.layoutManager= LinearLayoutManager(requireActivity()).apply {
            orientation = LinearLayoutManager.VERTICAL
        }
        binding.eqlistRV.adapter = adapter
        earthquakeViewModel.locationLiveData.observe(viewLifecycleOwner) {
            earthquakeViewModel.fetchData()
        }
        earthquakeViewModel.earthquakeLiveData.observe(viewLifecycleOwner) {
            //Log.d("TAG", "${it.features.size}")
            adapter.submitList(it.features)
        }
        return binding.root
    }


}