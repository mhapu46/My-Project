package com.example.blooddonor.db

val bloodGroupList= listOf("A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-")